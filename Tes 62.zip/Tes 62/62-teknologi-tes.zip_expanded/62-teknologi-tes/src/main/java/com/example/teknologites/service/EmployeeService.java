package com.example.teknologites.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.teknologites.domain.Employee;
import com.example.teknologites.repository.EmployeeRepository;

@Service
public class EmployeeService {

	@PersistenceContext
	private EntityManager entityManager;
	
	@Autowired
	private EmployeeRepository employeeRepository;
	
	public EntityManager getEntityManager() {
		return entityManager;
	}
	
	public List<Employee> getAll() {
		return employeeRepository.findAll();
	}
	
	public void insert(Employee employee) {
		employeeRepository.save(employee);
	}
	
	public Employee update(Employee employee) {
		Employee old = getById(employee.getId());
		old.setName(employee.getName());
		old.setMobile(employee.getMobile());
		old.setSalaray(employee.getSalaray());
		return getEntityManager().merge(employee);

	}
	
	public Employee getById(Integer id) {
		String q = "select e from Employee e where e.id = :id ";
		Query query = getEntityManager().createQuery(q);
		
		try {
			return (Employee) query.setParameter("id", id).getSingleResult();
		} catch (Exception e) {
			return null;
		}
	}
	
	public Employee delete(Integer id) {
		Employee entity = getById(id);
		if (entity == null) {
			return null;
		}
		getEntityManager().remove(entity);
		return entity;
	}
	
	@SuppressWarnings("unchecked")
	public List<Employee> getListByWhere(String search) {
		String q = "select e from Employee e where e.name = :search OR e.salaray = :search OR e.mobile = :search ";
		Query query = getEntityManager().createQuery(q);
		
		try {
			return (List<Employee>) query.setParameter("search", search).getResultList();
		} catch (Exception e) {
			return null;
		}
	}
}
