package com.example.teknologites.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Employee {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", nullable = false)
	private Integer id;

	@Column(name = "name", length = 512, nullable = true)
	private String name;
	
	@Column(name = "mobile", nullable = true)
	private Integer mobile;
	
	@Column(name = "salaray", nullable = true)
	private Integer salaray;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getMobile() {
		return mobile;
	}

	public void setMobile(Integer mobile) {
		this.mobile = mobile;
	}

	public Integer getSalaray() {
		return salaray;
	}

	public void setSalaray(Integer salaray) {
		this.salaray = salaray;
	}
	
}
