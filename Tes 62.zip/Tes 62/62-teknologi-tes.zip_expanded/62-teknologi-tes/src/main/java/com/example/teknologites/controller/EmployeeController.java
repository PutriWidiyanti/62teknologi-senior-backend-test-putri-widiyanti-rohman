package com.example.teknologites.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.teknologites.domain.Employee;
import com.example.teknologites.service.EmployeeService;

@RestController
@RequestMapping("/api/employee")
@Transactional(readOnly = true)
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;
	
	@GetMapping(path = "/index")
	public List<Employee> index() {
		List<Employee> employeeList = employeeService.getAll(); 
		return employeeList;
	}
	
	@GetMapping(path = "/search/{search}")
	public List<Employee> search(@PathVariable String search) {
		List<Employee> employeeList = new ArrayList<>();
		if (search == null || search == "") {
			employeeList = employeeService.getAll();
		} else {
			employeeList = employeeService.getListByWhere(search);
		}
		return employeeList;
	}
	
	@PostMapping(path = "/insert")
	@Transactional(readOnly = false)
	public Employee insert(@RequestBody Employee employee) throws Exception {
		
		employeeService.insert(employee);
		return employee;
	}
	
	@PostMapping(path = "/update")
	@Transactional(readOnly = false)
	public String update(@RequestBody Employee employee) throws Exception {
		Employee employeeOld = employeeService.getById(employee.getId());
		String response = null;
		
		if (employeeOld == null) {
			response = "Data dengan id = " + employee.getId() + " tidak ada";
		} else {
			employeeOld.setName(employee.getName());
			employeeOld.setMobile(employee.getMobile());
			employeeOld.setSalaray(employee.getSalaray());
			
			employeeService.update(employee);
			
			response = "Data dengan id = " + employee.getId() + " berhasil di update";
		}
		
		return response;
	}
	
	@DeleteMapping(path = "/delete/{id}")
	@Transactional(readOnly = false)
	public String delete(@PathVariable Integer id) throws Exception {
		employeeService.delete(id);
		
		return "Data dengan id = " + id + " berhasil di update";
	}
}
